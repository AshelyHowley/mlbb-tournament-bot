from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from app.bot.context import Services
from app.handlers.common import IsStaff, show, tg_user
from app.keyboards import admin as akb
from app.services.errors import ServiceError
from app.services.tournament import CONFIRM_WORD
from app.utils.text import esc, fmt_dt, parse_int, person

router = Router(name="admin_panel")
router.message.filter(IsStaff())
router.callback_query.filter(IsStaff())

ADMIN_TITLE = "🛠 <b>Админ-панель</b>"


class FinishTournament(StatesGroup):
    typing = State()      # waiting for the operator to type the confirmation word
    confirmed = State()   # word typed correctly - the final button is now live


async def _menu(cb_or_msg, svc: Services, state: FSMContext) -> None:
    is_main = svc.cfg.is_bot_admin(cb_or_msg.from_user.id)
    await state.clear()
    await show(cb_or_msg, ADMIN_TITLE, akb.admin_menu(is_main))


@router.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext, svc: Services) -> None:
    await _menu(message, svc, state)


@router.callback_query(F.data == "adm")
async def cb_admin(cb: CallbackQuery, state: FSMContext, svc: Services) -> None:
    await cb.answer()
    await _menu(cb, svc, state)


# ------------------------------------------------------------------ teams
@router.callback_query(F.data.regexp(r"^adm:t:\d{1,6}$"))
async def teams_list(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    total, page, last, rows = await svc.admin.teams_page(int(cb.data.split(":")[2]))
    text = f"👥 <b>Команды</b>\nВсего: <b>{total}</b>" + ("" if total else "\n\nПока нет ни одной команды.")
    await show(cb, text, akb.teams_list(rows, page, last))


@router.callback_query(F.data.regexp(r"^adm:tc:\d{1,18}$"))
async def team_card(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    tid = parse_int(cb.data.split(":")[2])
    try:
        team, members = await svc.admin.team_card(tid)
    except ServiceError as e:
        await show(cb, e.user_message, akb.to_admin())
        return
    who = [person(m['full_name'], m['username'], m['user_id']) for m in members]  # username is optional
    cap = next((w for m, w in zip(members, who) if m['is_captain']), 'ожидается')
    ready = "✅ Команда готова" if len(members) >= 2 else "⚠️ Не готова к участию (нужно минимум 2 игрока)"
    lines = [f"👥 <b>{esc(team['name'])}</b>", f"Капитан: {cap}",
             f"Регистратор: {person(team['creator_name'], team['creator_username'], team['created_by'])}",
             f"Состав: {len(members)}/5 — {ready}"]
    lines += [f"  {i}. {'👑 ' if m['is_captain'] else ''}{w}" for i, (m, w) in enumerate(zip(members, who), 1)]
    lines.append(f"Дата регистрации: {fmt_dt(team['created_at'], svc.cfg.timezone)}")
    await show(cb, "\n".join(lines), akb.team_card(tid))


@router.callback_query(F.data.regexp(r"^adm:td:\d{1,18}$"))
async def team_delete_ask(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    tid = parse_int(cb.data.split(":")[2])
    try:
        team, _ = await svc.admin.team_card(tid)
    except ServiceError as e:
        await show(cb, e.user_message, akb.to_admin())
        return
    await show(
        cb,
        f"⚠️ Удалить команду <b>{esc(team['name'])}</b>? Это действие необратимо.",
        akb.confirm_delete(f"adm:tdok:{tid}", f"adm:tc:{tid}"),
    )


@router.callback_query(F.data.regexp(r"^adm:tdok:\d{1,18}$"))
async def team_delete(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    try:
        await svc.admin.delete_team(parse_int(cb.data.split(":")[2]))
    except ServiceError as e:
        await show(cb, e.user_message, akb.to_admin())
        return
    await show(cb, "✅ Команда удалена.", akb.to_admin())


# ------------------------------------------------------------------ solo
@router.callback_query(F.data.regexp(r"^adm:s:\d{1,6}$"))
async def solo_list(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    total, page, last, rows = await svc.admin.solo_page(int(cb.data.split(":")[2]))
    text = f"👤 <b>Соло-игроки</b>\nВсего: <b>{total}</b>" + ("" if total else "\n\nПока никого нет.")
    await show(cb, text, akb.solo_list(rows, page, last))


@router.callback_query(F.data.regexp(r"^adm:sc:\d{1,18}$"))
async def solo_card(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    uid = parse_int(cb.data.split(":")[2])
    try:
        row = await svc.admin.solo_card(uid)
    except ServiceError as e:
        await show(cb, e.user_message, akb.to_admin())
        return
    await show(
        cb,
        f"👤 <b>Соло-игрок</b>\nTelegram: {person(row['full_name'], row['username'], row['user_id'])}\nРоль: <b>{esc(row['role'])}</b>\n"
        f"Дата регистрации: {fmt_dt(row['created_at'], svc.cfg.timezone)}",
        akb.solo_card(uid),
    )


@router.callback_query(F.data.regexp(r"^adm:sd:\d{1,18}$"))
async def solo_delete_ask(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    uid = parse_int(cb.data.split(":")[2])
    try:
        row = await svc.admin.solo_card(uid)
    except ServiceError as e:
        await show(cb, e.user_message, akb.to_admin())
        return
    await show(
        cb,
        f"⚠️ Удалить соло-игрока {person(row['full_name'], row['username'], row['user_id'])}? Это действие необратимо.",
        akb.confirm_delete(f"adm:sdok:{uid}", f"adm:sc:{uid}"),
    )


@router.callback_query(F.data.regexp(r"^adm:sdok:\d{1,18}$"))
async def solo_delete(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    try:
        await svc.admin.delete_solo(parse_int(cb.data.split(":")[2]))
    except ServiceError as e:
        await show(cb, e.user_message, akb.to_admin())
        return
    await show(cb, "✅ Соло-игрок удалён.", akb.to_admin())


# ------------------------------------------------------------------ registration switch
@router.callback_query(F.data == "adm:reg")
async def reg_status(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    open_ = await svc.reg.is_open()
    await show(cb, f"🔐 <b>Регистрация</b>\nСейчас: {'🔓 открыта' if open_ else '🔒 закрыта'}", akb.registration(open_))


@router.callback_query(F.data.in_({"adm:reg:set:0", "adm:reg:set:1"}))
async def reg_set(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    value = cb.data.endswith(":1")
    await svc.reg.set_open(value)  # explicit value -> idempotent on double click
    await show(cb, f"🔐 <b>Регистрация</b>\nСейчас: {'🔓 открыта' if value else '🔒 закрыта'}", akb.registration(value))


# ------------------------------------------------------------------ finish tournament (archive)
def _placements_text(p) -> str:
    return (
        f"👑 1 место: {esc(p.first_name) if p.first_name else 'не определено'}\n"
        f"🥈 2 место: {esc(p.second_name) if p.second_name else 'не определено'}\n"
        f"🥉 3 место: {esc(p.third_name) if p.third_name else 'не определено'}"
    )


@router.callback_query(F.data == "tf:start")
async def finish_start(cb: CallbackQuery, state: FSMContext, svc: Services) -> None:
    await cb.answer()
    await state.clear()
    p = await svc.tournaments.placements()
    if p.ready:
        await show(cb, f"⚠️ <b>Завершение турнира</b>\n\n{_placements_text(p)}\n\nВсе призовые места определены.", akb.finish_confirm(True))
    else:
        await show(
            cb,
            f"⚠️ <b>ТУРНИР ЕЩЁ НЕ ЗАВЕРШЁН</b>\n\nНе все призовые места определены.\n\n{_placements_text(p)}",
            akb.finish_confirm(False),
        )


@router.callback_query(F.data.in_({"tf:go", "tf:early"}))
async def finish_confirm2(cb: CallbackQuery, state: FSMContext, svc: Services) -> None:
    await cb.answer()
    p = await svc.tournaments.placements()
    await show(
        cb,
        "⚠️ <b>ЗАВЕРШЕНИЕ ТУРНИРА</b>\n\nТекущий турнир будет завершён. Все данные будут сохранены в 📚 История турниров. "
        "После этого будет создан новый чистый турнир.\n\nСохранятся: команды и составы, соло, сетка, серии, катки, "
        "1/2/3 места и статистика.\n\n" + _placements_text(p) + f"\n\nДля подтверждения введите слово: <b>{CONFIRM_WORD}</b>",
        akb.to_admin(),
    )
    await state.set_state(FinishTournament.typing)
    await state.update_data(force=cb.data == "tf:early")


@router.message(FinishTournament.typing, F.text)
async def finish_word(message: Message, state: FSMContext) -> None:
    if message.text.strip() != CONFIRM_WORD:
        await message.answer(f"❌ Введите точно: {CONFIRM_WORD}", reply_markup=akb.to_admin())
        return
    await state.set_state(FinishTournament.confirmed)
    await message.answer("Подтверждение получено. Нажмите кнопку для окончательного завершения турнира.", reply_markup=akb.finish_final())


@router.message(FinishTournament.typing, ~F.text)
async def finish_word_wrong_type(message: Message) -> None:
    await message.answer("Пожалуйста, отправьте текстом слово подтверждения.")


@router.callback_query(FinishTournament.confirmed, F.data == "tf:ok")
async def finish_ok(cb: CallbackQuery, state: FSMContext, svc: Services) -> None:
    await cb.answer()
    data = await state.get_data()
    await state.clear()
    try:
        tid, p = await svc.tournaments.finalize(tg_user(cb), force=bool(data.get("force")))
    except ServiceError as e:
        # covers TournamentNotReady (podium incomplete) and the rare NotFound race where another
        # staff member's concurrent finalize already archived this exact tournament first.
        await show(cb, e.user_message, akb.to_admin())
        return
    await show(
        cb,
        "✅ <b>ТУРНИР ЗАВЕРШЁН</b>\n\nРезультаты сохранены в 📚 История турниров.\n\n" + _placements_text(p) +
        "\n\nСоздан новый турнир.\n👥 Команд: 0\n👤 Соло: 0\n🎮 Матчей: 0\n🏆 Сетка: пустая",
        akb.finish_done(),
    )
    if p.ready:  # a fair final-results send only makes sense when the podium is real
        await cb.bot.send_message(
            cb.from_user.id,
            "📢 <b>ИТОГИ ТУРНИРА</b>\n\n" + _placements_text(p) + "\n\nКому отправить?",
            reply_markup=akb.sn_audience_final(tid),
        )


@router.callback_query(F.data == "tf:ok")
async def finish_ok_stale(cb: CallbackQuery) -> None:
    await cb.answer("Действие устарело, начните заново.", show_alert=True)
