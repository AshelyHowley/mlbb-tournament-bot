from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from app.bot.context import Services
from app.handlers.common import format_solo, format_team, menu_view, show
from app.keyboards.common import back_to_menu
from app.handlers.team import card_markup
from app.services.bracket import render_bracket

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext, svc: Services) -> None:
    await state.clear()
    text, markup = await menu_view(svc, message.from_user.id)
    await message.answer(text, reply_markup=markup)


@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext, svc: Services) -> None:
    await state.clear()
    text, markup = await menu_view(svc, message.from_user.id)
    await message.answer(text, reply_markup=markup)


@router.callback_query(F.data == "menu")
async def cb_menu(cb: CallbackQuery, state: FSMContext, svc: Services) -> None:
    await cb.answer()
    await state.clear()
    text, markup = await menu_view(svc, cb.from_user.id)
    await show(cb, text, markup)


@router.callback_query(F.data == "me")
async def cb_me(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    uid = cb.from_user.id
    reg = await svc.reg.my_registration(uid)
    if reg is None:
        text, markup = await menu_view(svc, uid)
        await show(cb, "Вы пока не зарегистрированы.\n\n" + text, markup)
        return
    parts, markup = [], back_to_menu()
    view = await svc.team.view_for_user(uid) if reg.has_team else None
    if view is not None:  # captain / member / registrar-only: each sees their own role
        parts.append(format_team(view, uid, title="👥 <b>Ваша регистрация: команда</b>"))
        markup = card_markup(view, uid)
    if reg.solo:
        parts.append(format_solo(reg, uid))
    await show(cb, "\n\n".join(parts) or "Вы пока не зарегистрированы.", markup)

@router.callback_query(F.data == "bracket")
async def cb_bracket(cb: CallbackQuery, svc: Services) -> None:
    await cb.answer()
    pages = render_bracket(await svc.admin.bracket_rows())
    await show(cb, pages[0], back_to_menu() if len(pages) == 1 else None)
    for i, extra in enumerate(pages[1:], 1):
        await cb.bot.send_message(cb.from_user.id, extra, reply_markup=back_to_menu() if i == len(pages) - 1 else None)


@router.callback_query(F.data == "noop")
async def cb_noop(cb: CallbackQuery) -> None:
    await cb.answer()
