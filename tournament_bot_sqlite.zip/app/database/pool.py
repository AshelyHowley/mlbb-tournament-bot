"""SQLite connection pool that emulates the asyncpg interface used by the bot.

Provides: acquire(), execute(), fetch(), fetchrow(), fetchval(), transaction(), close().
Converts $1, $2, ... placeholders to ? and returns dict-like records.
"""
from __future__ import annotations

import logging
import re
from contextlib import asynccontextmanager
from typing import Any, Optional, Sequence

import aiosqlite

log = logging.getLogger(__name__)

_PLACEHOLDER = re.compile(r"\$(\d+)")


def _to_qmark(sql: str) -> str:
    """$1, $2 ... -> ?"""
    return _PLACEHOLDER.sub("?", sql)


class Record(dict):
    """dict that also supports attribute and index access like dict."""

    def __getitem__(self, key):
        if isinstance(key, int):
            return list(self.values())[key]
        return super().__getitem__(key)


class Connection:
    def __init__(self, conn: aiosqlite.Connection):
        self._conn = conn
        self._conn.row_factory = aiosqlite.Row

    async def execute(self, sql: str, *args: Any) -> str:
        sql = _to_qmark(sql)
        cur = await self._conn.execute(sql, args)
        await self._conn.commit()
        # Mimic asyncpg status strings roughly
        if sql.strip().upper().startswith("INSERT"):
            return f"INSERT 0 {cur.lastrowid or 0}"
        if sql.strip().upper().startswith("UPDATE"):
            return f"UPDATE {cur.rowcount}"
        if sql.strip().upper().startswith("DELETE"):
            return f"DELETE {cur.rowcount}"
        return "OK"

    async def fetch(self, sql: str, *args: Any) -> list[Record]:
        sql = _to_qmark(sql)
        cur = await self._conn.execute(sql, args)
        rows = await cur.fetchall()
        return [Record(dict(r)) for r in rows]

    async def fetchrow(self, sql: str, *args: Any) -> Optional[Record]:
        rows = await self.fetch(sql, *args)
        return rows[0] if rows else None

    async def fetchval(self, sql: str, *args: Any) -> Any:
        row = await self.fetchrow(sql, *args)
        if row is None:
            return None
        return next(iter(row.values()))

    @asynccontextmanager
    async def transaction(self):
        await self._conn.execute("BEGIN")
        try:
            yield self
            await self._conn.commit()
        except Exception:
            await self._conn.rollback()
            raise

    async def close(self) -> None:
        await self._conn.close()


class Pool:
    """Minimal pool — SQLite is file-based, one connection is usually enough."""

    def __init__(self, path: str):
        self.path = path

    async def acquire(self) -> Connection:
        conn = await aiosqlite.connect(self.path)
        await conn.execute("PRAGMA foreign_keys = ON")
        await conn.execute("PRAGMA journal_mode = WAL")
        return Connection(conn)

    async def close(self) -> None:
        pass  # connections are closed by the caller


async def create_pool(dsn: str, **_: Any) -> Pool:
    """dsn: sqlite+aiosqlite:///./tournament.db or sqlite:///path"""
    path = dsn
    for prefix in ("sqlite+aiosqlite:///", "sqlite:///"):
        if path.startswith(prefix):
            path = path[len(prefix):]
            break
    if not path:
        raise ValueError("Empty SQLite path in DATABASE_URL")
    log.info("SQLite pool created: %s", path)
    return Pool(path)


class WrongDatabaseError(Exception):
    pass


async def verify_identity(conn: Connection, *args, **kwargs) -> None:
    """No-op for SQLite."""
    return None
